package dev.kryvex.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class KryvexClient implements ClientModInitializer {
    public static final Config CONFIG = new Config();
    private static KeyBinding openMenu;
    private static boolean gammaApplied = false;

    @Override public void onInitializeClient() {
        CONFIG.load();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.kryvex.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.kryvex"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) client.setScreen(new KryvexScreen());
            if (client.world != null && CONFIG.fullbright && !gammaApplied) { client.options.getGamma().setValue(16.0); gammaApplied = true; }
            if (!CONFIG.fullbright && gammaApplied) { client.options.getGamma().setValue(1.0); gammaApplied = false; }
            if (client.world != null && CONFIG.reduceParticles) client.options.getParticles().setValue(net.minecraft.particle.ParticlesMode.MINIMAL);
            if (client.player != null && CONFIG.autoSprint && !client.player.isSneaking()
                    && client.player.forwardSpeed > 0.0F) client.player.setSprinting(true);
            if (client.player != null && CONFIG.antiAfk && client.player.age % 1200 == 0)
                client.player.sendMessage(Text.literal("§8[Kryvex] §7Пора размяться — Anti-AFK напоминание."), true);
        });
        HudRenderCallback.EVENT.register((draw, tickCounter) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden) return;
            int y = 8;
            if (CONFIG.watermark) {
                draw.drawText(mc.textRenderer, "§bKRYVEX §8• §7Visual Client", 8, y, 0xFFFFFF, true); y += 12;
            }
            if (CONFIG.fpsHud) {
                draw.drawText(mc.textRenderer, "§fFPS §b" + mc.getCurrentFps(), 8, y, 0xFFFFFF, true); y += 12;
            }
            if (CONFIG.coordsHud) {
                var p = mc.player.getBlockPos();
                draw.drawText(mc.textRenderer, "§fXYZ §b" + p.getX() + " " + p.getY() + " " + p.getZ(), 8, y, 0xFFFFFF, true); y += 12;
            }
            if (CONFIG.clockHud) {
                draw.drawText(mc.textRenderer, "§fВремя §b" + (mc.world == null ? "--:--" : String.format("%02d:%02d", (int)((mc.world.getTimeOfDay()+6000)%24000)/1000, (int)(((mc.world.getTimeOfDay()+6000)%1000)*60/1000))), 8, y, 0xFFFFFF, true);
            }
            if (CONFIG.customCrosshair) { int cx=mc.getWindow().getScaledWidth()/2, cy=mc.getWindow().getScaledHeight()/2; draw.fill(cx-5,cy,cx+5,cy+1,0xFF55E6F2); draw.fill(cx,cy-5,cx+1,cy+5,0xFF55E6F2); }
            if (CONFIG.cosmeticTag) draw.drawText(mc.textRenderer, "✦ KRYVEX ✦", mc.getWindow().getScaledWidth()/2-28, 8, 0xFF8ADFFF, true);
        });
    }
}
