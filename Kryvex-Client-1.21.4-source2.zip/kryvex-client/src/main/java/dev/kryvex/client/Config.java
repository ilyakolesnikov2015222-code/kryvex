package dev.kryvex.client;

import net.minecraft.client.MinecraftClient;
import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class Config {
    public boolean watermark=true, fpsHud=true, coordsHud=true, clockHud=false;
    public boolean cosmeticTag=false, customCrosshair=false, fullbright=false, reduceParticles=false;
    public boolean autoSprint=false, antiAfk=false;
    public String theme="CYAN";
    public final List<String> friends = new ArrayList<>();
    private final Properties props = new Properties();
    private Path file() { return MinecraftClient.getInstance().runDirectory.toPath().resolve("config/kryvex.properties"); }
    public void load() {
        try { Path p=file(); if (!Files.exists(p)) return; try (Reader r=Files.newBufferedReader(p)) { props.load(r); }
            watermark=bool("watermark",watermark); fpsHud=bool("fpsHud",fpsHud); coordsHud=bool("coordsHud",coordsHud); clockHud=bool("clockHud",clockHud);
            cosmeticTag=bool("cosmeticTag",cosmeticTag); customCrosshair=bool("customCrosshair",customCrosshair); fullbright=bool("fullbright",fullbright); reduceParticles=bool("reduceParticles",reduceParticles);
            autoSprint=bool("autoSprint",autoSprint); antiAfk=bool("antiAfk",antiAfk); theme=props.getProperty("theme",theme);
            String f=props.getProperty("friends",""); if(!f.isBlank()) friends.addAll(Arrays.asList(f.split(",")));
        } catch(Exception ignored) { }
    }
    private boolean bool(String k, boolean d) { return Boolean.parseBoolean(props.getProperty(k,Boolean.toString(d))); }
    public void save() {
        props.setProperty("watermark",b(watermark)); props.setProperty("fpsHud",b(fpsHud)); props.setProperty("coordsHud",b(coordsHud)); props.setProperty("clockHud",b(clockHud));
        props.setProperty("cosmeticTag",b(cosmeticTag)); props.setProperty("customCrosshair",b(customCrosshair)); props.setProperty("fullbright",b(fullbright)); props.setProperty("reduceParticles",b(reduceParticles));
        props.setProperty("autoSprint",b(autoSprint)); props.setProperty("antiAfk",b(antiAfk)); props.setProperty("theme",theme); props.setProperty("friends",String.join(",",friends));
        try { Files.createDirectories(file().getParent()); try(Writer w=Files.newBufferedWriter(file())) { props.store(w,"Kryvex Client settings"); } } catch(IOException ignored) { }
    }
    private String b(boolean v){return Boolean.toString(v);}
}
